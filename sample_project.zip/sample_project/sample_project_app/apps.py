from django.apps import AppConfig


class SampleProjectAppConfig(AppConfig):
    name = 'sample_project_app'
