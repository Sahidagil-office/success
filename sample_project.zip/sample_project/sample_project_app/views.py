from django.shortcuts import render
from django.http import HttpResponse
from user_agents import parse

def my_func(request):
	return render(request, 'index.html')

def my_func1(request):
	if request.user_agent.browser:
		return HttpResponse('Desktop')
	else:
		return HttpResponse('Mobile')
